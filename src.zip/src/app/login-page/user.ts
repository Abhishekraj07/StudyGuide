export interface user
{
    userId:number;
    userName:string;
    firstName:string;
    lastName:string;
    age:number;
    contactNumber:number;
    email:string;
    password:string;
}