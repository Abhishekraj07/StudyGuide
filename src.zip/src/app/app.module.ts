import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { RegisterPageComponent } from './register-page/register-page.component';
import { AdminUpdateSetComponent } from './admin/admin-update-set/admin-update-set.component';
import { AdminAnswerQuestionsComponent } from './admin/admin-answer-questions/admin-answer-questions.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { NumberOfStudentsComponent } from './admin/number-of-students/number-of-students.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LoginPageComponent,
    RegisterPageComponent,
    AdminUpdateSetComponent,
    AdminAnswerQuestionsComponent,
    AdminDashboardComponent,
    NumberOfStudentsComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
