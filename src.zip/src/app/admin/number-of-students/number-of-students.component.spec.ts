import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NumberOfStudentsComponent } from './number-of-students.component';

describe('NumberOfStudentsComponent', () => {
  let component: NumberOfStudentsComponent;
  let fixture: ComponentFixture<NumberOfStudentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NumberOfStudentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NumberOfStudentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
