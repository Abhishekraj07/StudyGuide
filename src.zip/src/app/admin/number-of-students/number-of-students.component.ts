import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-number-of-students',
  templateUrl: './number-of-students.component.html',
  styleUrls: ['./number-of-students.component.css']
})
export class NumberOfStudentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
