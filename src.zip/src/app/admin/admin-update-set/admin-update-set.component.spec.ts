import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminUpdateSetComponent } from './admin-update-set.component';

describe('AdminUpdateSetComponent', () => {
  let component: AdminUpdateSetComponent;
  let fixture: ComponentFixture<AdminUpdateSetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminUpdateSetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminUpdateSetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
