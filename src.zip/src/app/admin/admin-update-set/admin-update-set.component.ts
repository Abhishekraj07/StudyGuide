import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-update-set',
  templateUrl: './admin-update-set.component.html',
  styleUrls: ['./admin-update-set.component.css']
})
export class AdminUpdateSetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
