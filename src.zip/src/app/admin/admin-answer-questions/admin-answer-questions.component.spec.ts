import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAnswerQuestionsComponent } from './admin-answer-questions.component';

describe('AdminAnswerQuestionsComponent', () => {
  let component: AdminAnswerQuestionsComponent;
  let fixture: ComponentFixture<AdminAnswerQuestionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminAnswerQuestionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminAnswerQuestionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
