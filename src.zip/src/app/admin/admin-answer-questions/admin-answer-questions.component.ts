import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-answer-questions',
  templateUrl: './admin-answer-questions.component.html',
  styleUrls: ['./admin-answer-questions.component.css']
})
export class AdminAnswerQuestionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
