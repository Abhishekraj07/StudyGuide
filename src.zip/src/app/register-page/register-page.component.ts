import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { user } from '../login-page/user';

@Component({
  selector: 'app-register-page',
  templateUrl: './register-page.component.html',
  styleUrls: ['./register-page.component.css']
})
export class RegisterPageComponent implements OnInit {
  registerForm: FormGroup;
  user: user;
  constructor() { }

  ngOnInit() {
    this.registerForm=new FormGroup({
      Username:new FormControl(),
      FirstName:new FormControl(),
      LastName:new FormControl(),
      Age:new FormControl(),
      Contactnumber:new FormControl(),
      Email:new FormControl(),
      Password:new FormControl(),
      ConfirmPassword:new FormControl()
    });


  }
  onSubmit()
  {
    if(this.registerForm.value.Password==this.registerForm.value.ConfirmPassword)
    {
     this.user= {
      userId:null,
      userName:this.registerForm.value.Username,
      firstName:this.registerForm.value.FirstName,
      lastName:this.registerForm.value.LastName,
      age:this.registerForm.value.Age,
      contactNumber:this.registerForm.value.Contactnumber,
      email:this.registerForm.value.Email,
      password:this.registerForm.value.Password,
     }

     // this.userService.addUser(this.user).subscribe((res)=>{console.log("SUCCESS")});
      console.log(this.user);

    }
    else{
      console.log("password doesnot matched");
    }
  }

}
